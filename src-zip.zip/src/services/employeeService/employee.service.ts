import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from '../../models/Employee';
import { EmployeeDto } from '../../models/EmployeeDto';


@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http: HttpClient) { }

  async getEmployees():Promise<Observable<Employee[]>>{
    try
    {
      return this.http.get<Employee[]>('https://localhost:7165/api/Employee/All');
    }
    catch(Exception){
      return new Observable<Employee[]>;
    }
  }

  async getEmployeeById(id:string):Promise<Observable<Employee>>{
    try
    {
      return this.http.get<Employee>('https://localhost:7165/api/Employee/'+id);
    }
    catch(Exception){
      return new Observable<Employee>;
    }
  }

  async addEmployee(emp:Employee){
    try
    {
      let response:boolean=true;
      this.http.post<Employee>('https://localhost:7165/api/Employee/Create',emp).subscribe({
        next: data => data,
        error: err => {
          console.log(err.message);
          response = false;
        },
        complete: () => {
          console.log('Created successfully');
          response = false;
        }
      })
    }
    catch(Exception){}
  }
}
