
export class EmployeeDto
{
    Id:string;
    FirstName:string;
    LastName:string;
    Email:string;
    JoiningDate:string;
    Department:string;
    Location:string;
    Role:string;

    constructor(Id:string,Department:string,FirstName:string,
        LastName:string,Email:string,JoiningDate:string,Location:string,Role:string)
    {
        this.Id=Id;
        this.Department= Department;
        this.FirstName= FirstName;
        this.LastName= LastName;
        this.Email= Email;
        this.JoiningDate= JoiningDate;
        this.Location= Location;
        this.Role= Role;
    }
}
