import { Component } from '@angular/core';

@Component({
  selector: 'app-addrole',
  standalone: true,
  imports: [],
  templateUrl: './addrole.component.html',
  styleUrl: './addrole.component.css'
})
export class AddroleComponent {

}
