import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { EmployeeDto } from '../../models/EmployeeDto';

@Component({
  selector: 'app-table',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './table.component.html',
  styleUrl: './table.component.css'
})
export class TableComponent {
@Input() tabledata:EmployeeDto[]=[]
//@Input() tabledata:any[]=[]
@Output() tabledataChange = new EventEmitter<any[]>();
@Output() checkboxChange = new EventEmitter<any[]>();
selectedIds:string[]=[]

sortColumn(prop:any)
{
  this.tabledataChange.emit(prop);
}

changeState()
{
  this.checkboxChange.emit([this.selectedIds.length]);
}
isSorted(columnName:string) {
  for (var i = 0; i < this.tabledata.length - 1; i++) {
      if (((this.tabledata[i] as any)[columnName]) > ((this.tabledata[i + 1]) as any)[columnName]) {
          return false;
      }
  }
  return true;
}

sortDataByColumn(columnName:any, orderBy = "asec") {
  var isAsec = this.isSorted(columnName);
  if (isAsec) {
      orderBy = "desc";
  }
  if (orderBy == 'asec') {
      this.tabledata.sort((a,b) => ((a as any)[columnName] > (b as any)[columnName] ? 1 : -1));
  }
  else {
      this.tabledata.sort((a, b) => ((a as any)[columnName] < (b as any)[columnName]) ? 1 : -1);
  }
}
selectEmployee(event:Event,id:string)
{
  if((event.target as HTMLInputElement).checked)
  {
    this.selectedIds.push(id)
  }
  else{
    this.selectedIds=this.selectedIds.filter(Id=>Id!=id);
  }
  console.log(this.selectedIds)
  this.changeState();
}
}
